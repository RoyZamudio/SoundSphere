package com.streamingsphere.unificado.pagos.abstraccion;

public class TarjetaDebito extends TarjetaBancaria {
    @Override
    public boolean realizarPago() {
        return true; // Simulamos éxito
    }
}
