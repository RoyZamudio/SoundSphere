package com.streamingsphere.unificado.pagos.abstraccion;

public abstract class MetodoDePago {
    public abstract boolean realizarPago();
}
