package com.streamingsphere.unificado.streaming.abstraccion;

import jakarta.servlet.http.*;

public interface Streaming {
    void verTransmision(HttpServletRequest request, HttpServletResponse response);
}
