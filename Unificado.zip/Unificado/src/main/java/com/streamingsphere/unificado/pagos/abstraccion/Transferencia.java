package com.streamingsphere.unificado.pagos.abstraccion;

public class Transferencia extends MetodoDePago {
    @Override
    public boolean realizarPago() {
        return true; // Simulamos éxito
    }
}
