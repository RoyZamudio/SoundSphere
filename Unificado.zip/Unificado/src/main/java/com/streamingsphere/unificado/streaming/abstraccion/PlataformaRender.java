package com.streamingsphere.unificado.streaming.abstraccion;

import jakarta.servlet.http.*;

public interface PlataformaRender {
    void renderizar(HttpServletRequest request, HttpServletResponse response);
}
