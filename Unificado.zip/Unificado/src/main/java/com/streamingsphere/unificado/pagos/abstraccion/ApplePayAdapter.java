package com.streamingsphere.unificado.pagos.abstraccion;

public class ApplePayAdapter extends MetodoDePago {
    private ApplePay applePay;

    public ApplePayAdapter(ApplePay applePay) {
        this.applePay = applePay;
    }

    @Override
    public boolean realizarPago() {
        return applePay.pagarConApple();
    }
}
