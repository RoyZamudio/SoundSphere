package com.streamingsphere.unificado.pagos.abstraccion;

public interface ApplePay {
    boolean pagarConApple();
}
