package com.streamingsphere.unificado.pagos.abstraccion;

public class ComprobantePago {
    private String mensaje;

    public ComprobantePago(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getMensaje() {
        return mensaje;
    }
}
