package com.streamingsphere.unificado.streaming.abstraccion;

import jakarta.servlet.http.*;

public class webRender implements PlataformaRender {
    @Override
    public void renderizar(HttpServletRequest request, HttpServletResponse response) {
        System.out.println("Renderizando para plataforma WEB.");
        try {
            request.getRequestDispatcher("streaming/presentacion/enVivo.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
