package com.streamingsphere.unificado.pagos.abstraccion;

public class TarjetaCredito extends TarjetaBancaria {
    @Override
    public boolean realizarPago() {
        return true; // Simulamos éxito
    }
}
