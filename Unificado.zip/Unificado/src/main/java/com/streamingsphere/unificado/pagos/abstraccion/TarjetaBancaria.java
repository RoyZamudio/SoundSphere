package com.streamingsphere.unificado.pagos.abstraccion;

public abstract class TarjetaBancaria extends MetodoDePago {

}
