package com.streamingsphere.unificado.pagos.abstraccion;

public class Pago {
    private MetodoDePago metodoPago;

    public Pago(MetodoDePago metodoPago) {
        this.metodoPago = metodoPago;
    }

    public boolean realizarPago() {
        return metodoPago.realizarPago();
    }
}
