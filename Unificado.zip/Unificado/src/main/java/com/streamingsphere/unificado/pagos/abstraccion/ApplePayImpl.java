package com.streamingsphere.unificado.pagos.abstraccion;

public class ApplePayImpl implements ApplePay {
    @Override
    public boolean pagarConApple() {
        return true; // Simulación exitosa
    }
}
